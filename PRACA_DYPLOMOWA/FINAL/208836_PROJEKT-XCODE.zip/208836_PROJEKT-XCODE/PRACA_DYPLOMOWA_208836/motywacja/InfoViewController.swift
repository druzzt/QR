//
//  InfoViewController.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 07.12.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit

class InfoViewController: UIViewController, UIWebViewDelegate {

    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.delegate = self
        if let url = URL(string: "https://druzzt.github.io/QR") {
            let request = URLRequest(url: url)
            webView.loadRequest(request)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func backToMenuButtonAction(_ sender: UIButton) {
        self.performSegue(withIdentifier: "backToMenuSegue", sender: self)
    }

}
