//
//  QRCodeGeneratorViewController.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 12.02.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit
import MobileCoreServices

class QRCodeGeneratorViewController: UIViewController, UIDocumentPickerDelegate {
    
    var                qrcodeImage: CIImage!
    var                target = ""
    var                thread_number = 6
    var                text_spread = 10
    var                stepDelay = 0.0005
    var                dataObjects = 0
    var                swBool = false
    var                queue = DispatchQueue(label: "com.Motywacja.QRCodeGeneratorViewController")
    var                queuedWorkItem: DispatchWorkItem!
    var                queuedQRs = [CIImage]()
    var                iterator=0
    
    @IBOutlet weak var stackViewAll: UIStackView!
    @IBOutlet weak var stackViewSubUp: UIStackView!
    @IBOutlet weak var stackViewSubMid: UIStackView!
    @IBOutlet weak var stackViewSubDown: UIStackView!
    
    @IBOutlet weak var imgQRCode:   UIImageView!
    @IBOutlet weak var imgQRCode2:  UIImageView!
    @IBOutlet weak var imgQRCode3:  UIImageView!
    @IBOutlet weak var imgQRCode4:  UIImageView!
    @IBOutlet weak var imgQRCode5:  UIImageView!
    @IBOutlet weak var imgQRCode6:  UIImageView!
    @IBOutlet weak var textField1:  UITextField!
    
    var t_imgQRCodes:[UIImageView]{
        
        return [self.imgQRCode,
                self.imgQRCode2,
                self.imgQRCode3,
                self.imgQRCode4,
                self.imgQRCode5,
                self.imgQRCode6]
        
    }
    
    var tField:[UITextField]{
        return [self.textField1]
    }
    
    
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        print("documentPicker")
        
        let fileName = url.lastPathComponent
        let temporaryURL=URL(fileURLWithPath: NSTemporaryDirectory(),isDirectory:true).appendingPathComponent(fileName)
        
        do {
            try FileManager.default.copyItem(at: url, to: temporaryURL)
        } catch {
            debugPrint("FileManager not available")
        }
        
        url.stopAccessingSecurityScopedResource()
        
        let destinationURL = FileManager.default.url(forUbiquityContainerIdentifier: nil)?
            .appendingPathComponent("Documents")
            .appendingPathComponent(fileName)
        
        do {
            try FileManager.default.setUbiquitous(true, itemAt: temporaryURL, destinationURL: destinationURL!)
        } catch {
            debugPrint("FileManager not available to store data")
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    // hide status bar -> readability of sequences (QR)
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        hideStackViews()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        if thread_number == 1 {
            self.t_imgQRCodes[0].frame = self.view.frame
            self.t_imgQRCodes[0].frame.origin.x = self.view.frame.minX
            self.t_imgQRCodes[0].frame.origin.y = self.view.frame.minY
        }
        
        start()
    }
    
    func hideStackViews() {
        //stackViewSubUp.isHidden = true
        //stackViewSubMid.isHidden = true
        //stackViewSubDown.isHidden = true
        //stackViewAll.isHidden = true
    }
    func showStackViews() {
        //stackViewSubUp.isHidden = false
        //stackViewSubMid.isHidden = false
        //stackViewSubDown.isHidden = false
        //stackViewAll.isHidden = false
    }
    
    
    // MARK: IBAction method implementation
    @IBAction func performButtonAction(_ sender: AnyObject) {
        self.queuedWorkItem.cancel()
    }
    @IBAction func performButtonDisplayAction(_ sender: UIButton) {
        displayQRonDisplay()
    }
    
    func start() {
        generateQRS()
    }
    
    func generateQRS() {
        let data: NSMutableArray = []
        if target == "test" || target == "rsa4096" {
            
            if qrcodeImage == nil {
                if target == "" {
                    return
                }
                textField1.text = target
                target = ""
                showStackViews()
                
                let filepath = String(data: textField1.text!.data(using: String.Encoding.utf8, allowLossyConversion: false)!,
                                      encoding: String.Encoding.utf8)
                
                let fileLocation = Bundle
                    .main
                    .path(forResource: filepath, ofType: "txt")!
                
                let text : String
                
                do
                {
                    text = try String(contentsOfFile: fileLocation)
                    
                    var ttext = ""
                    var i = 0
                    let len = text.characters.count
                    queuedWorkItem = DispatchWorkItem {
                        
                        for char in text.characters {
                            
                            ttext = "\(ttext)\(char)"
                            i+=1
                            
                            if ( i%self.text_spread == 0 ) || i == len {
                                
                                if i%self.text_spread == 0 {
                                    ttext = "{\(i)}\(ttext)"
                                }
                                
                                data.add(String(ttext).data(using: String.Encoding.utf8, allowLossyConversion: false)!)
                                
                                self.dataObjects+=1
                                
                                ttext = ""
                            }
                        }
                    }
                    queuedWorkItem.perform()
                    
                    queuedWorkItem = DispatchWorkItem {
                        
                        var j=0.0
                        
                        var tmpDisp = DispatchTime.now()
                        for i in data {
                            
                            let filter = CIFilter(name: "CIQRCodeGenerator")
                            filter!.setValue(i, forKey: "inputMessage")
                            
                            let seconds = Double(j)
                            j = j + self.stepDelay
                            
                            
                            DispatchQueue.main.async {
                                
                                if self.swBool == true {
                                    
                                    //debugPrint("true")
                                    filter!.setValue("L", forKey: "inputCorrectionLevel")
                                    
                                } else {
                                    
                                    //debugPrint("false")
                                    filter!.setValue("H", forKey: "inputCorrectionLevel")
                                    
                                }
                                
                                self.qrcodeImage = filter!.outputImage
                                
                                self.queuedQRs.append(self.qrcodeImage)
                                
                                self.iterator+=1
                                
                            }
                            //tmpDisp = dispatchTime
                        }
                        debugPrint(".")
                        
                        
                    }
                    debugPrint(#function, #line)
                } catch {
                    text = ""
                }
                debugPrint("Ready to generate")
                
                debugPrint(#function, #line)
            } else {
                
                hideStackViews()
                
                for im in t_imgQRCodes{
                    im.image=nil
                }
                
                qrcodeImage = nil
            }
            
            
            for tF in tField {
                
                tF.isEnabled = !tF.isEnabled
                
            }
            
        } else {
            
            generateTestGivenInString(str: target)
            
        }
        
        queuedWorkItem.perform()
        let alert = UIAlertController(title: "Ready to generate QR", message: "Choose", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Generate", style: .default, handler: { action in
            self.displayQRonDisplay()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { action in
            self.performButtonAction(self)
        }))
        self.present(alert, animated: true, completion: nil)
        //self.displayButton.setTitle("Ready to display", for: .normal)
    }
    
    func generateTestGivenInString(str: String) {
        let data: NSMutableArray = []
        if qrcodeImage == nil {
            
            if target == "" {
                return
            }
            
            showStackViews()
            
            let text : String
            do {
                text = str
                var ttext = ""
                var i = 0
                let len = text.characters.count
                
                for char in text.characters {
                    
                    ttext = "\(ttext)\(char)"
                    i+=1
                    
                    if ( i % text_spread == 0 ) || i == len {
                        
                        if i % text_spread == 0 {
                            ttext = "{\(i)}\(ttext)"
                        }
                        
                        data.add(String(ttext).data(using: String.Encoding.utf8, allowLossyConversion: false)!)
                        dataObjects+=1
                        ttext = ""
                    }
                }
            }
            
            var j=0.0
            var iterator=0
            
            for i in data {
                
                let filter = CIFilter(name: "CIQRCodeGenerator")
                filter!.setValue(i, forKey: "inputMessage")
                
                let seconds = Double(j)
                j = j + stepDelay
                debugPrint(j)
                
                let delay = seconds * Double(NSEC_PER_SEC)  // nanoseconds per seconds
                
                let dispatchTime = DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)
                
                DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                    
                    if self.swBool == true {
                        
                        debugPrint("true")
                        filter!.setValue("L", forKey: "inputCorrectionLevel")
                        
                    } else {
                        
                        //debugPrint("false")
                        filter!.setValue("H", forKey: "inputCorrectionLevel")
                        
                    }
                    
                    self.qrcodeImage = filter!.outputImage
                    self.displayQRCodeImage(iterator, qrciimage: filter!.outputImage!)
                    
                    iterator+=1
                    
                })
            }
        }
        else {
            
            hideStackViews()
            
            for im in t_imgQRCodes{
                
                im.image=nil
                
            }
            
            qrcodeImage = nil
            
        }
        
        for tF in tField {
            
            tF.isEnabled = !tF.isEnabled
            
        }
    }
    
    func displayQRonDisplay() {
        
        var g=0.0
        
        for (i,j) in queuedQRs.enumerated() {
            
            g = g + stepDelay
            debugPrint(g)
            
            let seconds = Double(g)
            
            let delay = seconds * Double(NSEC_PER_SEC)  // nanoseconds per seconds
            
            let dispatchTime = DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)
            
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                
                self.displayQRCodeImage(i, qrciimage: j)
                
            })
            
        }
        
    }
    
    
    func displayQRCodeImage(_ imageIter: Int, qrciimage: CIImage) {
        
        // possible improvement of speed, when these two are constant and calculated once per compilation
        let scaleX = self.t_imgQRCodes[imageIter%thread_number].frame.size.width / qrciimage.extent.size.width
        let scaleY = self.t_imgQRCodes[imageIter%thread_number].frame.size.height / qrciimage.extent.size.height
        // end of modification
        
        //let transformedImage = qrcodeImage.applying(CGAffineTransform(scaleX: scaleX, y: scaleY))
        let transformedImage = qrciimage.applying(CGAffineTransform(scaleX: scaleX, y: scaleY))
        t_imgQRCodes[imageIter%thread_number].image = UIImage(ciImage: transformedImage)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        debugPrint("Waiting for threads")
        debugPrint("already cancelled")
    }
}
