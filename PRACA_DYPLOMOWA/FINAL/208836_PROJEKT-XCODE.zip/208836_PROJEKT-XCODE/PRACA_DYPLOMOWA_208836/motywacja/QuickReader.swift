//
//  QuickReader.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 26.01.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit
import AVFoundation

class QuickReader: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    let session = AVCaptureSession()
    var previewLayer : AVCaptureVideoPreviewLayer?
    var captureDevices: AVCaptureDevice?
    let queue = DispatchQueue(label: "com.app.readingQRs")
    let backgroundQueue = DispatchQueue(label: "com.app.readingQRs",
                                        qos: .userInitiated,
                                        target: nil)
    
    var thread_number: Int = 4
    var maxFrameRate: Double = 240
    var cameraPositionOverloaded: AVCaptureDevicePosition = .back
    /* QR labels ON camera */
    @IBOutlet weak var QR1: UILabel!
    @IBOutlet weak var QR2: UILabel!
    @IBOutlet weak var QR3: UILabel!
    @IBOutlet weak var QR4: UILabel!
    
    /* Funcs for setting proper QR-label strings */
    var uilabel:[UILabel]{
        return [self.QR1, self.QR2, self.QR3, self.QR4]
    }
    
    var packets = [String]()
    
    /* Add the preview layer here */
    func addPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
        previewLayer?.bounds = self.view.bounds
        previewLayer?.position = CGPoint(x: self.view.bounds.midX, y: self.view.bounds.midY)
        self.view.layer.addSublayer(previewLayer!)
    }
    
    func previewLayerHide() {
        self.previewLayer?.isHidden = true
    }
    
    func previewLayerShow() {
        self.previewLayer?.isHidden = false
    }
    
    func hideQRLabels() {
        for i in uilabel {
            i.isHidden = true
        }
    }
    
    func showQRLabels() {
        for i in uilabel {
            i.isHidden = false
        }
    }
    
    func configureDevice() {
        if let device = captureDevices {
            for vFormat in captureDevices!.formats {
                var ranges = (vFormat as AnyObject).videoSupportedFrameRateRanges as! [AVFrameRateRange]
                let frameRates = ranges[0]
                if frameRates.maxFrameRate == maxFrameRate {
                    do {
                        try device.lockForConfiguration()
                        device.activeFormat = vFormat as! AVCaptureDeviceFormat
                        device.activeVideoMinFrameDuration = frameRates.minFrameDuration
                        device.activeVideoMaxFrameDuration = frameRates.maxFrameDuration
                        device.unlockForConfiguration()
                    } catch let e  {
                        debugPrint(e)
                    }
                }
            }
        }
    }
    
    func startSession() {
        
        var error: NSError?
        error = NSError(domain: "Camera session", code: 3, userInfo: nil)
        do {
            try session.addInput(AVCaptureDeviceInput(device: captureDevices))
        } catch let error {
            debugPrint(error)
        }
        
        if error != nil {
            print("Error: \(error?.localizedDescription)")
        }
        
        configureDevice()
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        self.view.layer.addSublayer(previewLayer!)
        previewLayer?.frame = self.view.layer.frame
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        output.metadataObjectTypes = output.availableMetadataObjectTypes
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        session.startRunning()
    }
    
    func setCamera(cameraPosition: AVCaptureDevicePosition) {
        self.cameraPositionOverloaded = cameraPosition
    }
    
    func setCamBefore() { /* override me! */ }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.thread_number = uilabel.count
        setCamBefore()
        session.sessionPreset = AVCaptureSessionPresetHigh
        let devices = AVCaptureDevice.devices()
        for device in devices! {
            if ((device as AnyObject).hasMediaType(AVMediaTypeVideo)) {
                if((device as AnyObject).position == cameraPositionOverloaded) {
                    captureDevices = device as? AVCaptureDevice
                    if captureDevices != nil {
                        startSession()
                    }
                }
            }
        }
        view.bringSubview(toFront: QR1)
        view.bringSubview(toFront: QR2)
        view.bringSubview(toFront: QR3)
        view.bringSubview(toFront: QR4)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        /* it is overriding to not do something not defined by me */
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        /* here the same with overriding - to not do something not proper */
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        session.stopRunning()
        //sortPackets()
    }
    
    func somethingToDoWhileCapturingMetadata(stringFromMetaData: String, threadId: Int) { /* override me */ }
    
    /* the most important here method - to capture the qr codes */
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!) {
        // dispatch_async(dispatch_get_main_queue(), {
        var i = 0
        for data in metadataObjects{
            
            //backgroundQueue.async {
            
            if (data as AnyObject).type == AVMetadataObjectTypeQRCode {
                
                // note the iterator is shared!
                //DispatchQueue.main.async {
                let x: String = (data as AnyObject).stringValue
                self.uilabel[i%thread_number].text = x
                //self.uilabel[i%4].text = "{\(i)}" + (data as AnyObject).stringValue
                somethingToDoWhileCapturingMetadata(stringFromMetaData: x, threadId: i%thread_number)
                i=i+1
                //}
                //i=i+1
                self.packets.append((data as AnyObject).stringValue)
                
                //}
            }
            //i=i+1
        }
        // })
    }
    
    func sortPackets() {
        debugPrint(packets)
        print("------------")
        let sortedPackets = packets.sorted()
        debugPrint(sortedPackets)
    }
}






