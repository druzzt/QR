//
//  ShortQRReadingViewController.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 13.02.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit
import MediaPlayer
import MobileCoreServices

class ShortQRReadingViewController: UIViewController {
    
    @IBOutlet weak var klatkavideo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("Setting up the ShortQRReadingViewController")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("View ShortQRReadingViewController appeared.")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        print("Memory is low")
    }
    
    @IBOutlet weak var PlayVideo: UIButton!
    @IBAction func playVideo(_ sender: AnyObject) {
        print("choose a file")
        let _ = startMediaBrowserFromViewController(self, usingDelegate: self)
        print("browsed")
    }
    
    func startMediaBrowserFromViewController(_ viewController: UIViewController,
                                             usingDelegate delegate: UINavigationControllerDelegate & UIImagePickerControllerDelegate) -> Bool {
        
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) == false {
            return false
        }
        
        let mediaUI = UIImagePickerController()
        mediaUI.sourceType = .savedPhotosAlbum
        mediaUI.mediaTypes = [kUTTypeMovie as NSString as String]
        mediaUI.allowsEditing = true
        mediaUI.delegate = delegate
        present(mediaUI, animated: true, completion: nil)
        return true
    }
    
}
// ta funkcja ma dostawac view, zeby potem moc odtworzyc w nim filmik wybrany z nowych metod ponizej SO ###
/*
 func useMeFromAClass(view: UIView ) -> UIImage {
 let testFrame : CGRect = CGRectMake(0,200,320,200)
 var testView : UIView = UIView(frame: testFrame)
 testView.backgroundColor = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1.0)
 testView.alpha=0.5
 self.view.addSubview(testView)
 // a przede wszystkim tym:
 captureFrame(URL: NSURL(fileURLWithPath: videoURL), timeInSeconds: 2, addToView: view)
 }*/

// Get Image From a Video [frames] long with [fps] ratio for the video.
func getImageFromVideo(_ videoURL: String, frames: Int64, fps: Int32) -> UIImage {
    do {
        /*// implementation
         if let url = NSBundle.mainBundle().URLForResource("MYMOVIE", withExtension: "MP4") {
         //captureFrame(url, timeInSeconds: 12, addToView:self.view)
         print(url)
         print(videoURL)
         }*/
        
        /*// get txt file and convert it to string
         let path = NSBundle.mainBundle().pathForResource("test", ofType: "txt")
         do {
         let text = try String(contentsOfFile: path!, encoding: NSUTF8StringEncoding)
         print(text)
         } catch {
         print("NO TEXT")
         }*/
        
        let asset = AVURLAsset(url: URL(fileURLWithPath: videoURL), options: nil)
        let imgGenerator = AVAssetImageGenerator(asset: asset)
        imgGenerator.appliesPreferredTrackTransform = true
        let cgImage = try imgGenerator.copyCGImage(at: CMTimeMake(frames, fps), actualTime: nil)
        let image = UIImage(cgImage: cgImage)
        return image
    } catch {
        print("Getting Image from Video Error: \(error)")
        let image : AnyObject? = nil
        return image as! UIImage
    }
    
}

// Preview image from a video frame, just a thumbnail ;/
func previewImageForLocalVideo(_ url:URL) -> UIImage?
{
    let asset = AVAsset(url: url)
    let imageGenerator = AVAssetImageGenerator(asset: asset)
    imageGenerator.appliesPreferredTrackTransform = true
    var time = asset.duration
    
    //If possible - take not the first frame
    // (it could be completely black or white on camera's videos)
    time.value = min(time.value, 2)
    
    do {
        let imageRef = try imageGenerator.copyCGImage(at: time, actualTime: nil)
        return UIImage(cgImage: imageRef)
    } catch let error as NSError{
        print("Image generation failed with error \(error)")
        return nil
    }
}


func finshedCapture(_ im:CGImage?, view:UIView, error:NSError?)  {
    if let img = im {
        print("OK")
        addImageViewWithImage(img, toView: view)
    }
    else {
        print("Fail")
    }
}
func addImageViewWithImage(_ img: CGImage, toView view:UIView) {
    DispatchQueue.main.async(execute: {
        let imgView = UIImageView(image: UIImage(cgImage: img))
        view.addSubview(imgView)
    })
}
func captureFrame(_ url:URL, timeInSeconds time:Int64, addToView view:UIView) {
    _ = AVAssetImageGenerator(asset: AVAsset(url: url))
    _ = NSValue(time: CMTimeMake(time, 1))
    
}




// MARK: - UIImagePickerControllerDelegate
extension ShortQRReadingViewController: UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let mediaType = info[UIImagePickerControllerMediaType] as! NSString
        
        dismiss(animated: true) {
            if mediaType == kUTTypeMovie {
                let moviePlayer =
                    MPMoviePlayerViewController(
                        contentURL:
                        info[UIImagePickerControllerMediaURL] as! URL)
                
                
                self.presentMoviePlayerViewControllerAnimated(moviePlayer)
            }
        }
    }
}

// MARK: - UINavigationControllerDelegate
extension ShortQRReadingViewController: UINavigationControllerDelegate {}


