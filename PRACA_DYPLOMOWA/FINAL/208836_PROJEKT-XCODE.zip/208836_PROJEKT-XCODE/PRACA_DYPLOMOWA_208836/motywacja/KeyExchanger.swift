//
//  KeyExchanger.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 07.12.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices

class KeyExchanger: QuickReader {
    
    var                klucz = "KLUCZ DO WYMIANY: <0x1113333333777777>"
    var                qrcodeImage: CIImage!
    var                target = ""
    var                text_spread = 10
    var                stepDelay = 0.005
    var                tmpStepDelay = 0.005
    var                dataObjects = 0
    var                swBool = true
    
    @IBOutlet weak var qr1img: UIImageView!
    @IBOutlet weak var qr2img: UIImageView!
    @IBOutlet weak var qr3img: UIImageView!
    @IBOutlet weak var qr4img: UIImageView!
    
    var t_imgQRCodes:[UIImageView]{
        return [self.qr1img,
                self.qr2img,
                self.qr3img,
                self.qr4img]
    }
    
    override func setCamBefore() {
        self.cameraPositionOverloaded = .front
    }
    
    func loadRSAKey() {
        
        let data: NSMutableArray = []
        
        let filepath = String(data: "rsa4096".data(using: String.Encoding.utf8, allowLossyConversion: false)!,
                              encoding: String.Encoding.utf8)
        
        let fileLocation = Bundle
            .main
            .path(forResource: filepath, ofType: "txt")!
        
        let text : String
        
        do
        {
            text = try String(contentsOfFile: fileLocation)
            klucz = text
            
        } catch(let error) {
            
        }
    }
    
    override func somethingToDoWhileCapturingMetadata(stringFromMetaData: String, threadId: Int) {
        animateQRexchange(str: stringFromMetaData, indexOfDisplay: threadId)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        for i in t_imgQRCodes {
            self.view.addSubview(i)
        }
        previewLayerHide()
        loadRSAKey()
        animateQRexchange(str: klucz, indexOfDisplay: 0)
        //animateQRexchange(str: "1111111111222222222233333333334444444444", indexOfDisplay: 0)
        
    }
    
    func animateQRexchange(str: String, indexOfDisplay: Int) {
        
        let data: NSMutableArray = []
        
        let text : String
        do {
            if str.isEmpty {
                text = klucz
            } else {
                text = str
            }
            var ttext = ""
            var i = 0
            let len = text.characters.count
            
            for char in text.characters {
                
                ttext = "\(ttext)\(char)"
                i+=1
                
                if ( i%text_spread == 0 ) || i == len {
                    
                    if i%text_spread == 0 {
                        ttext = "{\(i)}\(ttext)"
                    }
                    
                    data.add(String(ttext).data(using: String.Encoding.utf8, allowLossyConversion: false)!)
                    dataObjects+=1
                    ttext = ""
                }
            }
        }
        
        var j=0.0
        var iterator=indexOfDisplay
        
        for i in data {
            
            let filter = CIFilter(name: "CIQRCodeGenerator")
            filter!.setValue(i, forKey: "inputMessage")
            
            let seconds = Double(j)
            j = j + stepDelay
            
            let delay = seconds * Double(NSEC_PER_SEC)  // nanoseconds per seconds
            
            let dispatchTime = DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)
            
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                
                if self.swBool == true {
                    
                    debugPrint("true")
                    filter!.setValue("L", forKey: "inputCorrectionLevel")
                    
                } else {
                    
                    debugPrint("false")
                    filter!.setValue("H", forKey: "inputCorrectionLevel")
                    
                }
                
                self.qrcodeImage = filter!.outputImage
                self.displayQRCodeImage(iterator)
                
                iterator+=1
                
            })
        }
        
    }
    
    
    func displayQRCodeImage(_ imageIter: Int) {
        
        // possible improvement of speed, when these two are constant and calculated once per compilation
        let scaleX = self.t_imgQRCodes[imageIter%thread_number].frame.size.width / qrcodeImage.extent.size.width
        let scaleY = self.t_imgQRCodes[imageIter%thread_number].frame.size.height / qrcodeImage.extent.size.height
        // end of modification
        
        let transformedImage = qrcodeImage.applying(CGAffineTransform(scaleX: scaleX, y: scaleY))
        debugPrint(imageIter%thread_number)
        t_imgQRCodes[imageIter%thread_number].image = UIImage(ciImage: transformedImage)
        
    }
    
}
