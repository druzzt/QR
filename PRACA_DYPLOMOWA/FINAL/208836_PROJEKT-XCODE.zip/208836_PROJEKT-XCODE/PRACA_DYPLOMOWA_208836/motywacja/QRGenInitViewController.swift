//
//  QRGenInitViewController.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 09.11.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit
import MobileCoreServices

class QRGenInitViewController: UIViewController {
    
    var                thread_number = 6
    var                text_spread = 10
    var                stepDelay = 0.005
    var                tmpStepDelay = 0.005
    
    @IBOutlet weak var switchBooler: UISwitch!
    @IBOutlet weak var slider:      UISlider!
    @IBOutlet weak var slider2:     UISlider!
    @IBOutlet weak var textField1:  UITextField!
    @IBOutlet weak var btnAction:   UIButton!
    @IBOutlet weak var labelslider: UILabel!
    @IBOutlet weak var labelslider2: UILabel!
    
    var tField:[UITextField]{
        return [self.textField1]
    }
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        let currentValue = Int(sender.value)
        thread_number = currentValue
        DispatchQueue.main.async(execute: {
            self.labelslider.text = String(self.thread_number)
        })
    }
    
    @IBAction func slider2ValueChanged(_ sender: UISlider) {
        let currentValue = Int(sender.value)
        text_spread = currentValue
        DispatchQueue.main.async(execute: {
            self.labelslider2.text = String(self.text_spread)
        })
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
        
    }
    // hide status bar -> readability of sequences (QR)
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(QRGenInitViewController.dismissKeyboard))
        
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindToGenInit(segue: UIStoryboardSegue) {
        // unwinds to this place
    }
    
    // MARK: - Navigation
    @IBAction func backButtonAction(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "toMenuSegue", sender: self)
    }
    
    @IBAction func describeButtonAction(_ sender: UIBarButtonItem) {
        // tutaj zrob modal view controller ktory opowiada o tym widoku
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "genqr" {
            let nextScene =  segue.destination as! QRCodeGeneratorViewController
            nextScene.target = textField1.text!
            nextScene.thread_number = thread_number
            nextScene.text_spread = text_spread
            nextScene.stepDelay = stepDelay
            nextScene.swBool = switchBooler.isOn
        }
    }
    
    
}
