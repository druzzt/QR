//
//  PropagationTesting.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 07.12.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices

class PropagationTesting: QuickReader {
    
    @IBOutlet weak var bytePerSecLabel: UILabel!
    @IBOutlet weak var startStopButton: UIButton!
    @IBOutlet weak var dataCounter: UILabel!
    @IBOutlet weak var counterLabel: UILabel!
    @IBOutlet weak var firstQRcatchedIn: UILabel!
    @IBOutlet weak var tmpBytePerSecLabel: UILabel!
    
    var bytePerSecString = "B/s"
    var dataCounterVar: Int = 0
    var dataCounterVarSnap: Int = 0
    var timerCounter: Double = 0
    var timerCounterOld: Double = 0.0
    var timerCounterInterval: Double = 0.05
    var timerCounterIntervalBytePerSec : Double = 1.0
    var isTestRun: Bool = false
    var firstQRCatched: Bool = false
    var everyTwo: Bool = false
    
    var timeStart = Date()
    var timeEnd = Date()
    var timer = Timer()
    var timerForBytePerSec = Timer()
    
    var newMaxFrameRate: Double = 240
    var newCameraPositionOverloaded: AVCaptureDevicePosition = .back
    var newThreadNumber = 4
    var dataCountArray: Array<String> = []
    var threadCountArray: Array<Int> = []
    var lengCountArray: Array<Int> = []
    
    override func setCamBefore() {
        self.maxFrameRate = newMaxFrameRate
        self.cameraPositionOverloaded = newCameraPositionOverloaded
        self.thread_number = newThreadNumber
    }
    
    override func viewDidAppear(_ animated: Bool) {
        previewLayerHide()
        hideQRLabels()
        self.view.bringSubview(toFront: startStopButton)
    }
    
    override func somethingToDoWhileCapturingMetadata(stringFromMetaData: String, threadId: Int) {
        if isTestRun == true {
            if firstQRCatched == false {
                firstQRCatched = true
                let duration = timeStart.timeIntervalSinceNow
                self.firstQRcatchedIn.text = "\(-duration)"
            }
            
            dataCountArray.append(stringFromMetaData)
            threadCountArray.append(threadId)
            dataAdd(size: stringFromMetaData.characters.count)
            lengCountArray.append(stringFromMetaData.characters.count)
        }
    }
    
    func dataAdd(size: Int) {
        dataCounterVar = dataCounterVar + size
        dataCounter.text = "\(dataCounterVar) bytes total"
    }
    
    @IBAction func startStopButtonAction(_ sender: UIButton) {
        startOrStop()
    }
    
    func reset() {
        self.dataCounterVar = 0
        self.dataCounterVarSnap = 0
        self.timerCounter = 0.0
        self.timerCounterOld = 0.0
        self.counterLabel.text = "Sekund"
        self.dataCounter.text = "Bajtów"
        self.bytePerSecLabel.text = "Bajtów / sekundę"
        self.firstQRCatched = false
        startStopButton.titleLabel?.text = "Start"
    }
    
    func startOrStop() {
        if isTestRun == false {
            reset()
            startStopButton.titleLabel?.text = "Stop"
            isTestRun = true
            timeStart = Date()
            timer = Timer.scheduledTimer(timeInterval: timerCounterInterval,
                                         target:self,
                                         selector: #selector(PropagationTesting.updateCounter),
                                         userInfo: nil,
                                         repeats: true)
            
            timer = Timer.scheduledTimer(timeInterval: timerCounterIntervalBytePerSec,
                                         target:self,
                                         selector: #selector(PropagationTesting.updateCounterBytePerSec),
                                         userInfo: nil,
                                         repeats: true)
            
            
        } else {
            isTestRun = false
            startStopButton.titleLabel?.text = "Start"
        }
    }
    
    func updateCounterBytePerSec() {
        if isTestRun == true {
            let duration = Double(timeStart.timeIntervalSinceNow)
            let timeduration = -(duration)
            bytePerSecLabel.text = "avg \(round( Double(dataCounterVar)/timeduration)) "+bytePerSecString
            
            if everyTwo == false {
                everyTwo = true
                dataCounterVarSnap = dataCounterVar
            }
            
            if Double(timerCounter) >= 1.0 {
                let x =  dataCounterVar - dataCounterVarSnap
                if x > 0 {
                    tmpBytePerSecLabel.text = "now \(round(Double(dataCounterVar - dataCounterVarSnap))) B/s"
                }
                timerCounter = 0.0
            } else {
                
            }
        }
    }
    
    func updateCounter() {
        if isTestRun == true {
            
            let duration = -timeStart.timeIntervalSinceNow
            counterLabel.text = "\(duration) s"
            
            if timerCounter >= 1.0 {
                timerCounterOld = duration
                dataCounterVarSnap = dataCounterVar
                
            } else {
                timerCounter = duration - timerCounterOld
            }
            debugPrint(timerCounter)
            
        }
    }
    
    func catchFirstQRTiming() {
        
    }
    
}
