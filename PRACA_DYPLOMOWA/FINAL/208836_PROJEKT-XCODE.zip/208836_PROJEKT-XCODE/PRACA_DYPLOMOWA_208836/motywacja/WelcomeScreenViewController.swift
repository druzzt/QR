//
//  WelcomeScreenViewController.swift
//  motywacja
//
//  Created by Arkadiusz Lewandowski on 24.05.2016.
//  Copyright © 2016 Arkadiusz Lewandowski. All rights reserved.
//

import Foundation
import UIKit
import MediaPlayer
import MobileCoreServices

class WelcomeScreenViewController: UIViewController {
    
    @IBOutlet weak var welcomeScreenBackground: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(WelcomeScreenViewController.longPressed(_:)))
        self.view.addGestureRecognizer(longPressRecognizer)
    }
    
    @IBAction func unwindToThisViewController(segue: UIStoryboardSegue) {
        // unwinds to this place
    }
    
    //MARK: Initialization
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func longPressed(_ sender: UILongPressGestureRecognizer) {
        
    }
    
}
